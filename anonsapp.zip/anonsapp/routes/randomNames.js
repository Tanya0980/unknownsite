var names = ['lillyelephant', 'perpendicular', 'tangent', 'rattacky', 'horizontal', 'fackar007', 'hacker', 'voltage', 'Gendew'];

module.exports = names;