const mongoose = require('mongoose');

var postSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user'
    },
    username: String,

    postText: String,

    date: {

        type: Date,
        default: new Date()
    },
    likes: [],
    dislikes: [],
    loves: []
})

module.exports = mongoose.model('post', postSchema);